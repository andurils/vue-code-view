# vue-code-view

// 示例参考
https://github.com/simonguo/react-code-view
react-to-vue

// 代码编辑
https://github.surmon.me/vue-codemirror/

cnpm install --save codemirror
npm i --save lodash

https://codesandbox.io/s/github/vuejs/vuejs.org/tree/master/src/v2/examples/vue-20-dynamic-components-with-binding?file=/index.html:942-1011

https://github.com/vuejs/jsx#installation

# vue-cli

通过 vue ui 命令使用 GUI 运行更多的特性脚本

## css 配置

https://cli.vuejs.org/zh/guide/css.html#css-%E7%9B%B8%E5%85%B3

## Project setup

```
yarn install
```

### Compiles and hot-reloads for development

```
yarn serve
```

### Compiles and minifies for production

```
yarn build
```

### Lints and fixes files

```
yarn lint
```
